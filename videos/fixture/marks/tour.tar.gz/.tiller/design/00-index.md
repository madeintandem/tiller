# Acme Platform: design inputs

Acme runs a certification program: technicians train and test, employers
enroll and renew, projects are submitted for audit, and the program reports
on all of it annually. The platform replaces a set of spreadsheets and PDF
forms with one Rails application.

- 01-foundation.md: the application skeleton, authentication, and roles
- 02-forms.md: the certification form engine and its renderer
- 03-payments.md: Stripe checkout and invoicing
- 04-notifications.md: email delivery and reminders
- 05-audits.md: the audit engine and the auditor review flow
- 06-reporting.md: the annual report and CSV export
