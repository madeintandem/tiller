# Rotate the staging API keys

Proposed chore created by `tiller add chore`. Write the contract here before
a human triages it: what is being done, why, and what "done" means.

## What

## Why

## Done when
