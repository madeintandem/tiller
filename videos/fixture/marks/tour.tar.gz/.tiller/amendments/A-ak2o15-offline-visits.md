# Auditors need site visits to work offline

## Why

Two pilot audits were held in buildings with no signal. The auditors took
notes on paper and typed them in that night, which is the work this platform
exists to remove.

## What changes

The Audit Engine gains one feature, Offline visit capture, and On-site visit
scheduling is revised to hand a visit to the device before the auditor leaves.
One new question holds the new feature until it is answered.

## What to watch

Visit data sits on a device until it syncs. How long it may stay there is the
open question, and the answer shapes the storage design.
