# Reminders by text message as well as email

## Why

Technicians in the field miss renewal emails. The program asked for the same
reminders by text message, on the schedule the email reminders already keep.

## What changes

Notifications gains one feature, SMS delivery, beside Email delivery. The
reminder scheduler is untouched; it gains a second channel to send through.

## What to watch

Text messages cost money per send. The feature's spec needs a monthly cap.
