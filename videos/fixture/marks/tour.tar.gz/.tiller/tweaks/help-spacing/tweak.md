# Adjust help text spacing

Proposed tweak created by `tiller add tweak`. Write the contract here before
a human triages it: what is being adjusted, why, and what "done" means.

## What

## Why

## Done when
