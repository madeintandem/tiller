# Invoicing

## Summary

Issue a numbered invoice for every paid enrollment, downloadable as a PDF from the employer's account.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.
