---
node: F-jkw15s
criteria:
  - id: C1
    statement: The feature's primary route renders and its request specs pass
    polarity: introduce
    binding: { type: command, run: "true" }
---

# Acceptance

The acceptance contract binds to the project's test command; the criterion
above is satisfied when the route renders and its specs are green.
