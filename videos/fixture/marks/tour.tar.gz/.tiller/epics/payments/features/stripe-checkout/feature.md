# Stripe checkout

## Summary

One checkout session per enrollment fee, confirmed by Stripe's webhook rather than by the browser's return.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.

Refunds go back through the same checkout session, so the webhook handler
also records Stripe's refund events against the enrollment.
