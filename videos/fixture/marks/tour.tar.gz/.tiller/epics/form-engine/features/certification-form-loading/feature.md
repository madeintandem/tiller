# Certification form loading

## Summary

Load the certification definition families from their published schema and render each form version the program still accepts.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.
