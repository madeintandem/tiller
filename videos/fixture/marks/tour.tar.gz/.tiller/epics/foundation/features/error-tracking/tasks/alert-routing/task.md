# Alert routing

## Approach

Send each captured exception to whoever is on call for the part of the app it
came from. Areas come from the controller namespace, the on-call schedule
lives in `config/on_call.yml`, and anything without an owner goes to the
platform channel so nothing is dropped.

## Steps

1. Add `AlertRouter`, which takes a captured exception and returns a destination.
2. Map controller namespaces to areas in `config/alert_areas.yml`.
3. Deliver through the mailer for email destinations and the chat webhook for channels.
4. Hold repeats of the same fingerprint to one alert every 10 minutes.

## Done when

- An exception raised under `Admin::` reaches the admin on-call address.
- An exception with no owning area reaches the platform channel.
- A burst of 50 identical exceptions sends one alert.
