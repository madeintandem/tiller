# seed data

## Approach

Implement the slice named in the title, prove it with a request spec, and
leave the build green.
