# Error tracking

## Summary

Capture every unhandled exception with its request context and route alerts to whoever is on call.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.
