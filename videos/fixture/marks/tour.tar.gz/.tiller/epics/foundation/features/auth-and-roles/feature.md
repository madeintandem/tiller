# Authentication and roles

## Summary

Sessions, login, and the four roles the program knows: technician, employer, auditor, and administrator, each guarding the routes it may reach.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.
