# App scaffold

## Summary

Stand up the application skeleton: the build, the entrypoint, one health route, and a CI pipeline that runs the suite on every push.

## Specification

The feature lands behind the existing application shell and reuses the
project's own conventions for models, routes, and views. Every user-facing
state is reachable from the primary navigation, and every write is covered
by a request spec.
